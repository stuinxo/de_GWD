<?php
require_once('auth.php');
if (empty($auth)) {
    header('Location: login.php');
    exit;
}
$de_GWDconf = gwd_read_conf_object();
$pageAlias = isset($de_GWDconf->address->alias) && is_scalar($de_GWDconf->address->alias) ? trim((string)$de_GWDconf->address->alias) : '';
$pageTitle = ($pageAlias !== '') ? $pageAlias : '寒月';
$checkJellyfin = (isset($de_GWDconf->app->jellyfin) && is_scalar($de_GWDconf->app->jellyfin)) ? (string)$de_GWDconf->app->jellyfin : null;
$checkBitwarden = (isset($de_GWDconf->app->bitwarden) && is_scalar($de_GWDconf->app->bitwarden)) ? (string)$de_GWDconf->app->bitwarden : null;
?>
<!DOCTYPE html>
<html>

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

<title><?php echo gwd_h($pageTitle); ?></title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">

  <link href="favicon.ico" rel="icon" type="image/x-icon" />

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <meta name="csrf-token" content="<?php echo gwd_h($csrfToken ?? ''); ?>">
  <script src="js/gwd-csrf.js"></script>

</head>

<body id="page-top" class="sidebar-toggled">
  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

    <a class="navbar-brand mr-1" href="index.php">寒月</a>
    <button class="btn btn-sm btn-outline-light mx-3" data-toggle="modal" data-target="#markThis">备注本机</button>

    <button id="sidebarToggle" class="btn btn-link btn-sm text-white order-1 order-sm-0" href="javascript:void(0)">
      <i class="fas fa-bars"></i>
    </button>
<span class="float-right badge text-info"><?php passthru('sudo /opt/de_GWD/ui-checkEditionARM');?></span>

    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
    </form>

    <!-- Navbar -->
    <ul class="nav navbar-nav ml-auto ml-md-0">
      <li class="nav-item no-arrow mx-1" style="display:<?php if ($checkJellyfin === 'installed') echo 'block'; else echo 'none';?>">
        <a class="nav-link" href="javascript:void(0)" onclick="window.open(location.protocol+'//'+location.hostname+':8097')">
          <i class="fab fa-youtube"></i>
          <span>Jellyfin</span>
        </a>
      </li>

      <li class="nav-item no-arrow mx-1" style="display:<?php if ($checkBitwarden === 'installed') echo 'block'; else echo 'none';?>">
        <a class="nav-link" href="javascript:void(0)" onclick="window.open(location.protocol+'//'+location.hostname+':8099')">
          <i class="fas fa-shield-alt"></i>
          <span>Bitwarden</span>
        </a>
      </li>
      
      <li class="nav-item no-arrow mx-1">
        <a class="nav-link" href="/admin/" target="_blank">
          <i class="fab fa-raspberry-pi"></i>
          <span>Pi-Hole</span>
        </a>
      </li>
    </ul>

  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav toggled">
      <li class="nav-item">
        <a class="nav-link" href="index.php">
          <i class="fas fa-tachometer-alt"></i>
          <span>概览</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="forward.php">
          <i class="fas fa-project-diagram"></i>
          <span>中转</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="ddns.php">
          <i class="fas fa-ethernet"></i>
          <span>DDNS & Wireguard</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="app.php">
          <i class="fab fa-app-store-ios"></i>
          <span>应用</span></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="nodes.php">
          <i class="fas fa-stream"></i>
          <span>节点管理</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="update.php">
          <i class="fas fa-arrow-alt-circle-up"></i>
          <span>更新</span></a>
      </li>
      <li class="nav-item">
        <a id="buttonLogout" class="nav-link" href="javascript:void(0)">
          <i class="fas fa-sign-out-alt"></i>
          <span>注销</span></a>
      </li>
    </ul>

    <div id="content-wrapper" class="mx-auto" style="max-width: 1600px;">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="index.php">概览</a>
          </li>
          <li class="breadcrumb-item active">节点管理</li>
        </ol>


<!-- Modal -->
<div id="markThis" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="markThisLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 id="markThisLabel" class="modal-title">备注本机</h5>
      </div>
      <div class="modal-body">
        <input id="markName" type="text" class="form-control" placeholder="备注名" required="required" value="<?php echo gwd_h($de_GWDconf->address->alias ?? ''); ?>">
      </div>
      <div class="modal-footer">
        <button id="buttonMarkThis" type="button" class="btn btn-outline-dark btn-sm">应用</button>
      </div>
    </div>
  </div>
</div>


        <!-- Page Content -->
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-stream"></i>
            节点编辑
<span class="float-right mt-n1 mb-n2">
<button id="buttonAddLine" type="button" class="btn btn-secondary btn-sm mt-1" style="border-Radius: 0px;">
  添加
</button>

<button id="buttonSaveNode" type="button" class="btn btn-secondary btn-sm mt-1" style="border-Radius: 0px;">
  <span id="buttonSaveNodeLoading"></span>
  <span>保存</span>
</button>
</span>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered table-striped text-center text-nowrap my-2">
                <thead>
                  <tr>
                    <th class="text-nowrap text-center">序号</th>
                    <th class="text-nowrap text-center"><———— 节点地址 ————></th>
                    <th class="text-nowrap text-center"><———— 节点名 ————></th>
                    <th class="text-nowrap text-center"><———————— UUID ————————></th>
                    <th class="text-nowrap text-center"><—— PATH ——></th>
                    <th class="text-nowrap text-center"><i class="fas fa-caret-square-up fa-lg"></i></th>
                    <th class="text-nowrap text-center"><i class="fas fa-caret-square-down fa-lg"></i></th>
                  </tr>
                </thead>
                <tbody id="nodeTable">
<?php 
$v2nodesList = (isset($de_GWDconf->v2node) && is_array($de_GWDconf->v2node)) ? array_values($de_GWDconf->v2node) : [];
$v2nodeCount = count($v2nodesList);
for( $i=0; $i<$v2nodeCount; $i++){
  $nodeItem = is_object($v2nodesList[$i]) ? $v2nodesList[$i] : new stdClass();
  $num = $i+1;
  $domain = gwd_h($nodeItem->domain ?? '');
  $tls = gwd_h($nodeItem->tls ?? '');
  $name = gwd_h($nodeItem->name ?? '');
  $path = gwd_h($nodeItem->path ?? '');
  $uuid = gwd_h($nodeItem->uuid ?? '');
print <<<EOT
<tr>
<td class="align-middle">$num</td>
<td class="align-middle">
  <div class="input-group">
      <input type="text" class="form-control" value="$domain">
    <div class="input-group-append">
      <button type="button" class="btn btn-secondary btn-sm" value="$tls" onclick="commitTls(this)">tls</button>
    </div>
  </div>
</td>
<td class="align-middle"><input type="text" class="form-control" value="$name"></td>
<td class="align-middle"><input type="text" class="form-control" value="$uuid"></td>
<td class="align-middle"><input type="text" class="form-control" value="$path"></td>
<td class="align-middle"><button type="button" class="form-control btn btn-outline-secondary btn-sm" style="border-Radius: 0px;" onclick="moveUp(this)"><i class="fas fa-caret-up"></i></button></td>
<td class="align-middle"><button type="button" class="form-control btn btn-outline-secondary btn-sm" style="border-Radius: 0px;" onclick="moveDown(this)"><i class="fas fa-caret-down"></i></button></td>
</tr>
EOT;
}
?>
                </tbody>
              </table>
            </div>
          </div>
        </div>


      </div>
      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © de_GWD by JacyL4 2017 ~ 2025</span>
          </div>
        </div>
      </footer>

    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->
<script>
function commitTls(commitTls){
var tlsValue = $(commitTls).val() || '';
if ($('#commitTlsModal').length === 0) {
  $('body').append(`
<div id="commitTlsModal" class="modal fade" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body">
        <div class="input-group">
          <input id="serverName" type="text" class="form-control">
          <div class="input-group-append">
            <button id="serverNameSave" type="button" class="btn btn-secondary btn-sm">保存</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
  `);
}
$('#serverName').val(tlsValue);
$('#serverNameSave').off('click').on('click', function(){
  $(commitTls).val($('#serverName').val());
  $('#commitTlsModal').modal('hide');
});
$('#commitTlsModal').modal('show');
}

function moveUp(obj) { 
var current = $(obj).closest('tr');
var prev = current.prev('tr');
if (prev.length) { 
current.insertBefore(prev);
$("#nodeTable tr").each(function(idx){ $(this).find("td:first").text(idx + 1); });
}
}

function moveDown(obj) { 
var current = $(obj).closest('tr');
var next = current.next('tr');
if (next.length) { 
current.insertAfter(next);
$("#nodeTable tr").each(function(idx){ $(this).find("td:first").text(idx + 1); });
}
}



$(function(){
$('#buttonLogout').click(function(){
$.post('auth.php', {logout:'true'}).always(function(){window.location.href="login.php"})
})

$('#buttonMarkThis').click(function(){
markNametxt=$('#markName').val()
$.post('./act/markThis.php', {markName:markNametxt}, function(result){window.location.reload()})
})

$('#buttonAddLine').click(function(){
  var i = $("#nodeTable td:nth-child(1)").length;
  $('#nodeTable').append(`
                          <tr>
                          <td class="align-middle">${i+1}</td>
                          <td class="align-middle">
                            <div class="input-group">
                                <input type="text" class="form-control" value="">
                              <div class="input-group-append">
                                <button type="button" class="btn btn-secondary btn-sm" value="" onclick="commitTls(this)">tls</button>
                              </div>
                            </div>
                          </td>
                          <td class="align-middle"><input type="text" class="form-control" value=""></td>
                          <td class="align-middle"><input type="text" class="form-control" value=""></td>
                          <td class="align-middle"><input type="text" class="form-control" value=""></td>
                          <td class="align-middle"><button type="button" class="form-control btn btn-outline-secondary btn-sm" style="border-Radius: 0px;" onclick="moveUp(this)"><i class="fas fa-caret-up"></i></button></td>
                          <td class="align-middle"><button type="button" class="form-control btn btn-outline-secondary btn-sm" style="border-Radius: 0px;" onclick="moveDown(this)"><i class="fas fa-caret-down"></i></button></td>
                          </tr>
                          `)
})

$('#buttonSaveNode').click(function(){
$("#buttonSaveNodeLoading").attr("class", "spinner-border spinner-border-sm")
var nodeList = []
var domain, tls, name, path, uuid
var len = $("#nodeTable td:nth-child(1)").length
var trList = $("#nodeTable").children("tr")
for( let i = 0; i<len; i++){
    var tdArr = trList.eq(i).find("td")
    var domain = tdArr.eq(1).find('input').val()
    var tls = tdArr.eq(1).find('button').val()
    var name = tdArr.eq(2).find('input').val()
    var uuid = tdArr.eq(3).find('input').val()
    var path = tdArr.eq(4).find('input').val()
    if (tls == '' ) {
    var tls = domain.split(':')[0]
    }
    if (domain !== '' && name !== '' && uuid !== '' ) {
    nodeList.push({domain, tls, name, uuid, path})
    }
}
$.post("./act/NodeSave.php", {nodeList:nodeList}, function(result){
  $("#buttonSaveNodeLoading").removeClass()
  if (/^skipped \d+/.test($.trim(result || ''))) {
    alert('已保存，但有 ' + $.trim(result).split(' ')[1] + ' 个无效节点被跳过（地址/名称不能含空白，UUID 仅限字母数字-_）')
  }
  window.location.href="index.php"
}).fail(function(xhr){
  $("#buttonSaveNodeLoading").removeClass()
  alert($.trim(xhr.responseText) || "保存节点失败")
})
})
})
</script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin.min.js"></script>
  
</body>

</html>

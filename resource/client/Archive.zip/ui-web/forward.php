<?php
require_once('auth.php');
if (empty($auth)) {
    header('Location: login.php');
    exit;
}
$de_GWDconf = gwd_read_conf_object();
$pageAlias = isset($de_GWDconf->address->alias) && is_scalar($de_GWDconf->address->alias) ? trim((string)$de_GWDconf->address->alias) : '';
$pageTitle = ($pageAlias !== '') ? $pageAlias : '寒月';
$checkJellyfin = (isset($de_GWDconf->app->jellyfin) && is_scalar($de_GWDconf->app->jellyfin)) ? (string)$de_GWDconf->app->jellyfin : '';
$checkBitwarden = (isset($de_GWDconf->app->bitwarden) && is_scalar($de_GWDconf->app->bitwarden)) ? (string)$de_GWDconf->app->bitwarden : '';

$checkCer = file_exists('/var/www/ssl/de_GWD.cer');

$checkcoredns = exec('sudo systemctl is-active coredns');
$DoGsConf = file_exists('/opt/de_GWD/coredns/corefile') ? strpos((string)@file_get_contents('/opt/de_GWD/coredns/corefile'), 'grpc://.:') : false;

$checkBlock53 = (isset($de_GWDconf->FORWARD->block53) && is_scalar($de_GWDconf->FORWARD->block53)) ? (string)$de_GWDconf->FORWARD->block53 : '';

$checkVtrui = exec('sudo systemctl is-active vtrui');
$vtruiConf = file_exists('/opt/de_GWD/vtrui/config.json') ? json_decode((string)@file_get_contents('/opt/de_GWD/vtrui/config.json')) : null;
$hasFwd0Inbound = false;
if (is_object($vtruiConf) && isset($vtruiConf->inbounds) && is_array($vtruiConf->inbounds)) {
    foreach ($vtruiConf->inbounds as $ib) {
        if (is_object($ib) && isset($ib->tag) && $ib->tag === 'forward0') {
            $hasFwd0Inbound = true;
            break;
        }
    }
}
$checkFWD0 = !$hasFwd0Inbound;

$checkVtrui1 = exec('sudo systemctl is-active vtrui1');
$checkFWD1OB = explode("\n", (string)shell_exec('sudo /opt/de_GWD/ui-checkFWD1'));
$checkFWD1 = file_exists('/opt/de_GWD/vtrui1/config.json');

$checkRproxyS = exec('sudo systemctl is-active RproxyS');
$RproxySconf = file_exists('/opt/de_GWD/RproxyS/config.json') ? json_decode((string)@file_get_contents('/opt/de_GWD/RproxyS/config.json')) : null;

$checkRproxyC = exec('sudo systemctl is-active RproxyC');
$RproxyCconf = file_exists('/opt/de_GWD/RproxyC/config.json') ? json_decode((string)@file_get_contents('/opt/de_GWD/RproxyC/config.json')) : null;

$fwdDomain = (isset($de_GWDconf->FORWARD->domain) && is_scalar($de_GWDconf->FORWARD->domain)) ? (string)$de_GWDconf->FORWARD->domain : '';
$fwdToken = (isset($de_GWDconf->FORWARD->token) && is_scalar($de_GWDconf->FORWARD->token))
    ? (string)$de_GWDconf->FORWARD->token
    : ((isset($de_GWDconf->FORWARD->APIkey) && is_scalar($de_GWDconf->FORWARD->APIkey)) ? (string)$de_GWDconf->FORWARD->APIkey : '');
$doGsPort = (isset($de_GWDconf->FORWARD->DoGs->port) && is_scalar($de_GWDconf->FORWARD->DoGs->port)) ? (string)$de_GWDconf->FORWARD->DoGs->port : '';
$fwd0Port = (isset($de_GWDconf->FORWARD->FWD0->port) && is_scalar($de_GWDconf->FORWARD->FWD0->port)) ? (string)$de_GWDconf->FORWARD->FWD0->port : '';
$fwd1Port = (isset($de_GWDconf->FORWARD->FWD1->port) && is_scalar($de_GWDconf->FORWARD->FWD1->port)) ? (string)$de_GWDconf->FORWARD->FWD1->port : '';
$rproxyStunnelPort = (isset($de_GWDconf->FORWARD->Rproxy->server->tunnel->port) && is_scalar($de_GWDconf->FORWARD->Rproxy->server->tunnel->port)) ? (string)$de_GWDconf->FORWARD->Rproxy->server->tunnel->port : '';
$rproxyStunnelUUID = (isset($de_GWDconf->FORWARD->Rproxy->server->tunnel->uuid) && is_scalar($de_GWDconf->FORWARD->Rproxy->server->tunnel->uuid)) ? (string)$de_GWDconf->FORWARD->Rproxy->server->tunnel->uuid : '';
$rproxyCtunnelAddr = (isset($de_GWDconf->FORWARD->Rproxy->client->tunnel->address) && is_scalar($de_GWDconf->FORWARD->Rproxy->client->tunnel->address)) ? (string)$de_GWDconf->FORWARD->Rproxy->client->tunnel->address : '';
$rproxyCtunnelUUID = (isset($de_GWDconf->FORWARD->Rproxy->client->tunnel->uuid) && is_scalar($de_GWDconf->FORWARD->Rproxy->client->tunnel->uuid)) ? (string)$de_GWDconf->FORWARD->Rproxy->client->tunnel->uuid : '';
?>
<!DOCTYPE html>
<html>

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

<title><?php echo gwd_h($pageTitle); ?></title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">

  <link href="favicon.ico" rel="icon" type="image/x-icon" />

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <script src="js/jquery.qrcode.min.js"></script>
  <meta name="csrf-token" content="<?php echo gwd_h($csrfToken ?? ''); ?>">
  <script src="js/gwd-csrf.js"></script>

</head>

<body id="page-top" class="sidebar-toggled">
  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">

    <a class="navbar-brand mr-1" href="index.php">寒月</a>
    <button class="btn btn-sm btn-outline-light mx-3" data-toggle="modal" data-target="#markThis">备注本机</button>
    
    <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
      <i class="fas fa-bars"></i>
    </button>
<span class="float-right badge text-info"><?php passthru('sudo /opt/de_GWD/ui-checkEditionARM');?></span>

    <!-- Navbar Search -->
    <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
    </form>

    <!-- Navbar -->
    <ul class="nav navbar-nav ml-auto ml-md-0">
      <li class="nav-item no-arrow mx-1" style="display:<?php if ($checkJellyfin === 'installed') echo 'block'; else echo 'none';?>">
        <a class="nav-link" href="javascript:void(0)" onclick="window.open(location.protocol+'//'+location.hostname+':8097')">
          <i class="fab fa-youtube"></i>
          <span>Jellyfin</span>
        </a>
      </li>

      <li class="nav-item no-arrow mx-1" style="display:<?php if ($checkBitwarden === 'installed') echo 'block'; else echo 'none';?>">
        <a class="nav-link" href="javascript:void(0)" onclick="window.open(location.protocol+'//'+location.hostname+':8099')">
          <i class="fas fa-shield-alt"></i>
          <span>Bitwarden</span>
        </a>
      </li>
      
      <li class="nav-item no-arrow mx-1">
        <a class="nav-link" href="/admin/" target="_blank">
          <i class="fab fa-raspberry-pi"></i>
          <span>Pi-Hole</span>
        </a>
      </li>
    </ul>

  </nav>

  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="sidebar navbar-nav toggled">
      <li class="nav-item">
        <a class="nav-link" href="index.php">
          <i class="fas fa-tachometer-alt"></i>
          <span>概览</span>
        </a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="forward.php">
          <i class="fas fa-project-diagram"></i>
          <span>中转</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="ddns.php">
          <i class="fas fa-ethernet"></i>
          <span>DDNS & Wireguard</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="app.php">
          <i class="fab fa-app-store-ios"></i>
          <span>应用</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="nodes.php">
          <i class="fas fa-stream"></i>
          <span>节点管理</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="update.php">
          <i class="fas fa-arrow-alt-circle-up"></i>
          <span>更新</span></a>
      </li>
      <li class="nav-item">
        <a id="buttonLogout" class="nav-link" href="javascript:void(0)">
          <i class="fas fa-sign-out-alt"></i>
          <span>注销</span></a>
      </li>
    </ul>


    <div id="content-wrapper" class="mx-auto" style="max-width: 1600px;">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="index.php">概览</a>
          </li>
          <li class="breadcrumb-item active">中转</li>
        </ol>


<!-- Modal -->
<div id="markThis" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="markThisLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 id="markThisLabel" class="modal-title">备注本机</h5>
      </div>
      <div class="modal-body">
        <input id="markName" type="text" class="form-control" placeholder="备注名" required="required" value="<?php echo gwd_h($de_GWDconf->address->alias ?? ''); ?>">
      </div>
      <div class="modal-footer">
        <button id="buttonMarkThis" type="button" class="btn btn-outline-dark btn-sm">应用</button>
      </div>
    </div>
  </div>
</div>


        <!-- Page Content -->      
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-shield-alt"></i>
            域名与证书
<span id="CERbutton" class="float-right mt-n1 mb-n2" style="display:<?php if ($checkCer === true) echo 'block'; else echo 'none';?>">
<button id="buttonGenCER" type="button" class="btn <?php if ($checkCer === true) echo 'btn-outline-success'; else echo 'btn-outline-secondary';?> btn-sm mt-1" style="border-Radius: 0px;">install</button>
<button id="buttonCheckCER" type="button" class="btn btn-outline-secondary btn-sm mt-1 ml-4" style="border-Radius: 0px;">
  <span id="buttonCheckCERloading"></span>
  <span id="buttonCheckCERtxt">检查证书有效期</span>
</button>
</span>
<span id="CERswitch" class="float-right mt-n1 mb-n2" style="display:<?php if ($checkCer === true) echo 'none'; else echo 'block';?>">
<button type="button" class="btn btn-secondary btn-sm mt-1" style="border-Radius: 0px;" onclick="CERswitch()">展开</button>
</span>
          </div>

          <div id="CERbody" class="card-body" style="display:<?php if ($checkCer === true) echo 'block'; else echo 'none';?>">
            <div class="form-row">
              <div class="col-md-5 input-group my-2">
                <div class="input-group-prepend">
                  <span class="input-group-text justify-content-center" style="min-width: 120px;">域名</span>
                </div>
                  <input id="CFdomain" type="text" class="form-control" value="<?php echo gwd_h($fwdDomain); ?>">
              </div>

              <div class="col-md-7 input-group my-2">
                <div class="input-group-prepend">
                  <span class="input-group-text justify-content-center" style="min-width: 120px;">CF Token</span>
                </div>
                  <input id="CFtoken" type="text" class="form-control" placeholder="Cloudflare API Token (Zone:DNS:Edit)" value="<?php echo gwd_h($fwdToken); ?>">
              </div>
            </div>
          </div>
        </div>



        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-reply"></i>
            DNS over gRPC server
<span id="DoGsButton" class="float-right mt-n1 mb-n2" style="display:<?php if ($DoGsConf !== false) echo 'block'; else echo 'none';?>">
<div class="btn-group">
<button id="buttonDoGsStop" type="button" class="btn btn-outline-secondary btn-sm mt-1" style="border-Radius: 0px;">
  <span id="buttonDoGsStopLoading"></span>
  <span>关闭</span>
</button>
<button id="buttonDoGsSave" type="button" class="btn <?php if ($DoGsConf !== false && $checkcoredns === 'active') echo 'btn-success'; else echo 'btn-outline-secondary';?> btn-sm mt-1" style="border-Radius: 0px;">
  <span id="buttonDoGsSaveLoading"></span>
  <span>应用</span>
</button>
</div>
</span>
<span id="DoGsSwitch" class="float-right mt-n1 mb-n2" style="display:<?php if ($DoGsConf !== false) echo 'none'; else echo 'block';?>">
<button type="button" class="btn btn-secondary btn-sm mt-1" style="border-Radius: 0px;" onclick="DoGsSwitch()">展开</button>
</span>
          </div>

          <div id="DoGsBody" class="card-body" style="display:<?php if ($DoGsConf !== false) echo 'block'; else echo 'none';?>">
            <div class="form-row">
              <div class="col-md-2 input-group my-2">
                <div class="input-group-prepend">
                  <span class="input-group-text">端口</span>
                </div>
                  <input id="DoGsPort" type="text" class="form-control" value="<?php echo gwd_h($doGsPort); ?>">
              </div>

              <div class="col-md-3 input-group my-2">
                <div class="input-group-prepend">
                  <span class="input-group-text">地址</span>
                </div>
                <input type="text" class="form-control" value="<?php echo gwd_h($fwdDomain . ':' . $doGsPort); ?>" READONLY>
              </div>
            </div>
          </div>
        </div>

        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-reply"></i>
            默认中转线
<span id="FWD0button" class="float-right mt-n1 mb-n2" style="display:<?php if ($checkFWD0 === false) echo 'block'; else echo 'none';?>">
<div class="btn-group">
<button id="buttonBlock53off" type="button" class="btn btn-outline-secondary btn-sm mt-1" style="border-Radius: 0px;">
  <span id="buttonBlock53offLoading"></span>
  <span>关闭</span>
</button>
<button id="buttonBlock53on" type="button" class="btn <?php if ($checkBlock53 === 'on') echo 'btn-success'; else echo 'btn-outline-secondary';?> btn-sm mt-1" style="border-Radius: 0px;">
  <span id="buttonBlock53onLoading"></span>
  <span>不对外开放53端口</span>
</button>
</div>

<button id="buttonFWD0Add" type="button" class="btn btn-secondary btn-sm mt-1" style="border-Radius: 0px;">
  添加 UUID
</button>

<div class="btn-group">
<button id="buttonFWD0stop" type="button" class="btn btn-outline-secondary btn-sm mt-1" style="border-Radius: 0px;">
  <span id="buttonFWD0stopLoading"></span>
  <span>关闭</span>
</button>
<button id="buttonFWD0save" type="button" class="btn <?php if ($checkFWD0 === false && $checkVtrui === 'active') echo 'btn-success'; else echo 'btn-outline-secondary';?> btn-sm mt-1" style="border-Radius: 0px;">
  <span id="buttonFWD0saveLoading"></span>
  <span>应用</span>
</button>
</div>
</span>
<span id="FWD0switch" class="float-right mt-n1 mb-n2" style="display:<?php if ($checkFWD0 === false) echo 'none'; else echo 'block';?>">
<button type="button" class="btn btn-secondary btn-sm mt-1" style="border-Radius: 0px;" onclick="FWD0switch()">展开</button>
</span>
          </div>

          <div id="FWD0body" class="card-body" style="display:<?php if ($checkFWD0 === false) echo 'block'; else echo 'none';?>">
            <div class="form-row">
              <div class="col-md-2">
                <div class="input-group my-2">
                  <div class="input-group-prepend">
                    <span class="input-group-text">端口</span>
                  </div>
                  <input id="FWD0port" type="text" class="form-control" value="<?php echo gwd_h($fwd0Port); ?>">
                </div>
              </div>

              <div class="col-md-3">
                <div class="input-group my-2">
                  <div class="input-group-prepend">
                    <span class="input-group-text">地址</span>
                  </div>
                  <input type="text" class="form-control" value="<?php echo gwd_h($fwdDomain . ':' . $fwd0Port); ?>" READONLY>
                </div>
              </div>

              <div id="FWD0List" class="col-md-7">
<?php 
$fwd0Uuids = (isset($de_GWDconf->FORWARD->FWD0->uuid) && is_array($de_GWDconf->FORWARD->FWD0->uuid)) ? array_values($de_GWDconf->FORWARD->FWD0->uuid) : [];
for( $i=0; $i<count($fwd0Uuids); $i++){
  $fwd0Item = is_object($fwd0Uuids[$i]) ? $fwd0Uuids[$i] : new stdClass();
  $FWD0num = $i + 1;
  $FWD0uuid = gwd_h($fwd0Item->FWD0uuid ?? '');
  $FWD0mark = gwd_h($fwd0Item->FWD0mark ?? '');
print <<<EOT
              <div>
                <div class="input-group my-2 fwd0-row">
                  <div class="input-group-prepend">
                    <span class="input-group-text">UUID</span>
                  </div>
                    <input id="FWD0uuid$FWD0num" type="text" class="form-control" value="$FWD0uuid">
                  <div class="input-group-prepend input-group-append">
                    <button type="button" class="btn btn-secondary" onclick="FWD0qr(this)">显示二维码</button>
                  </div>
                  <div class="input-group-prepend input-group-append">
                    <span class="input-group-text">备注</span>
                  </div>
                    <input id="FWD0mark$FWD0num" type="text" class="form-control col-md-3" value="$FWD0mark">
                </div>
              </div>
<div id="FWD0qrpop$FWD0num" class="modal fade" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title mx-auto" >默认中转线二维码 - $FWD0mark</h5>
      </div>
      <div class="modal-body">
        <div id="FWD0qrcode$FWD0num" class="text-center mb-3"></div>
        <div class="input-group">
          <input type="text" id="FWD0link$FWD0num" class="form-control" readonly>
          <div class="input-group-append">
            <button class="btn btn-outline-primary" type="button" onclick="copyNodeLink('FWD0link$FWD0num', this)">复制</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
EOT;
}
?>
              </div>          
            </div>
          </div>
        </div>


        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-reply-all"></i>
            并行中转线
<span id="FWD1button" class="float-right mt-n1 mb-n2" style="display:<?php if ($checkFWD1 === true) echo 'block'; else echo 'none';?>">
<button id="buttonFWD1Add" type="button" class="btn btn-secondary btn-sm mt-1" style="border-Radius: 0px;">
  添加 UUID
</button>

<div class="btn-group">
<button id="buttonFWD1stop" type="button" class="btn btn-outline-secondary btn-sm mt-1" style="border-Radius: 0px;">
  <span id="buttonFWD1stopLoading"></span>
  <span>关闭</span>
</button>
<button id="buttonFWD1save" type="button" class="btn <?php if ($checkFWD1 === true && $checkVtrui1 === 'active') echo 'btn-success'; else echo 'btn-outline-secondary';?> btn-sm mt-1" style="border-Radius: 0px;">
  <span id="buttonFWD1saveLoading"></span>
  <span>应用</span>
</button>
</div>
</span>
<span id="FWD1switch" class="float-right mt-n1 mb-n2" style="display:<?php if ($checkFWD1 === true) echo 'none'; else echo 'block';?>">
<button type="button" class="btn btn-secondary btn-sm mt-1" style="border-Radius: 0px;" onclick="FWD1switch()">展开</button>
</span>
          </div>

          <div id="FWD1body" class="card-body" style="display:<?php if ($checkFWD1 === true) echo 'block'; else echo 'none';?>">
            <div class="form-row">
              <div class="col-md-2">
                <div class="input-group my-2">
                  <div class="input-group-prepend">
                    <span class="input-group-text">端口</span>
                  </div>
                  <input id="FWD1port" type="text" class="form-control" value="<?php echo gwd_h($fwd1Port); ?>">
                </div>
              </div>

              <div class="col-md-3">
                <div class="input-group my-2">
                  <div class="input-group-prepend">
                    <span class="input-group-text">地址</span>
                  </div>
                  <input type="text" class="form-control" value="<?php echo gwd_h($fwdDomain . ':' . $fwd1Port); ?>" READONLY>
                </div>

<div class="btn-group">
  <label class="input-group-text">上级v2节点</label>
  <button id="FWD1upstream" class="btn btn-outline-secondary dropdown-toggle" type="button" data-toggle="dropdown" value="<?php echo gwd_h($checkFWD1OB[1] ?? ''); ?>"><?php echo gwd_h($checkFWD1OB[0] ?? ''); ?></button>
  <div id="FWD1upstreamDrop" class="dropdown-menu">
<?php
$v2nodes = (isset($de_GWDconf->v2node) && is_array($de_GWDconf->v2node)) ? array_values($de_GWDconf->v2node) : [];
for( $i=0; $i<count($v2nodes); $i++){
  $nodeObj = is_object($v2nodes[$i]) ? $v2nodes[$i] : new stdClass();
  $address = gwd_h($nodeObj->domain ?? '');
  $name = gwd_h($nodeObj->name ?? '');
print <<<EOT
<button class='dropdown-item' href='#' id='FWD1upstream$i' value="$address" onclick="buttonFWD1upstream(this)">$name</button>
EOT;
}
?>
  </div>
</div>
              </div>

              <div id="FWD1List" class="col-md-7">
<?php 
$fwd1Uuids = (isset($de_GWDconf->FORWARD->FWD1->uuid) && is_array($de_GWDconf->FORWARD->FWD1->uuid)) ? array_values($de_GWDconf->FORWARD->FWD1->uuid) : [];
for( $i=0; $i<count($fwd1Uuids); $i++){
  $fwd1Item = is_object($fwd1Uuids[$i]) ? $fwd1Uuids[$i] : new stdClass();
  $FWD1num = $i + 1;
  $FWD1uuid = gwd_h($fwd1Item->FWD1uuid ?? '');
  $FWD1mark = gwd_h($fwd1Item->FWD1mark ?? '');
print <<<EOT
              <div>
                <div class="input-group my-2 fwd1-row">
                  <div class="input-group-prepend">
                    <span class="input-group-text">UUID</span>
                  </div>
                    <input id="FWD1uuid$FWD1num" type="text" class="form-control" value="$FWD1uuid">
                  <div class="input-group-prepend input-group-append">
                    <button type="button" class="btn btn-secondary" onclick="FWD1qr(this)">显示二维码</button>
                  </div>
                  <div class="input-group-prepend input-group-append">
                    <span class="input-group-text">备注</span>
                  </div>
                    <input id="FWD1mark$FWD1num" type="text" class="form-control col-md-3" value="$FWD1mark">
                </div>
              </div>

<div id="FWD1qrpop$FWD1num" class="modal fade" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title mx-auto" >并行中转线二维码 - $FWD1mark</h5>
      </div>
      <div class="modal-body">
        <div id="FWD1qrcode$FWD1num" class="text-center mb-3"></div>
        <div class="input-group">
          <input type="text" id="FWD1link$FWD1num" class="form-control" readonly>
          <div class="input-group-append">
            <button class="btn btn-outline-primary" type="button" onclick="copyNodeLink('FWD1link$FWD1num', this)">复制</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

EOT;
}
?>
              </div>
            </div>
          </div>
        </div>

    <div class="card bg-light border-secondary mb-3">
          <div class="card-header">
            <i class="fas fa-share-square"></i>
            内网穿透 服务端 (公网设置)
<span id="RproxySbutton" class="float-right mt-n1 mb-n2" style="display:<?php if (empty($RproxySconf) === false) echo 'block'; else echo 'none';?>">
<div class="btn-group">
<button id="buttonRproxySstop" type="button" class="btn btn-outline-secondary btn-sm mt-1" style="border-Radius: 0px;">
  <span id="buttonRproxySstopLoading"></span>
  <span>关闭</span>
</button>
<button id="buttonRproxySsave" type="button" class="btn <?php if (empty($RproxySconf) === false && $checkRproxyS === 'active') echo 'btn-success'; else echo 'btn-outline-secondary';?> btn-sm mt-1" style="border-Radius: 0px;">
  <span id="buttonRproxySsaveLoading"></span>
  <span>应用</span>
</button>
</div>
</span>
<span id="RproxySswitch" class="float-right mt-n1 mb-n2" style="display:<?php if (empty($RproxySconf) === false) echo 'none'; else echo 'block';?>">
<button type="button" class="btn btn-secondary btn-sm mt-1" style="border-Radius: 0px;" onclick="RproxySswitch()">展开</button>
</span>
          </div>
          <div id="RproxySbody" class="card-body" style="display:<?php if (empty($RproxySconf) === false) echo 'block'; else echo 'none';?>">
            <div class="form-row">
             <div class="col-md-2 input-group my-2">
                <div class="input-group-prepend">
                  <span class="input-group-text">端口</span>
                </div>
                  <input id="RproxyStunnelPort" type="text" class="form-control" value="<?php echo gwd_h($rproxyStunnelPort); ?>">
              </div>

              <div class="col-md-3 input-group my-2">
                <div class="input-group-prepend">
                  <span class="input-group-text">对接地址</span>
                </div>
                <input type="text" class="form-control" value="<?php echo gwd_h($fwdDomain . ':' . $rproxyStunnelPort); ?>" READONLY>
              </div>

              <div class="col-md-7 input-group my-2">
                <div class="input-group-prepend">
                  <span class="input-group-text">UUID</span>
                </div>
                  <input id="RproxyStunnelUUID" type="text" class="form-control" value="<?php echo gwd_h($rproxyStunnelUUID); ?>">
                </div>
            </div>

            <div class="card mb-3 mt-2">
              <div class="card-header">
                端口映射型
<span id="RproxyS1Button" class="float-right mt-n1 mb-n2" style="display:<?php if (strpos(json_encode($RproxySconf), 'mapping') !== false) echo 'block'; else echo 'none';?>">
<button id="buttonRproxyS1Add" type="button" class="btn btn-secondary btn-sm mt-1" style="border-Radius: 0px;">添加</button>
<button id="buttonRproxyS1Stop" type="button" class="btn btn-outline-secondary btn-sm mt-1" style="border-Radius: 0px;">关闭</button>
</span>
<span id="RproxyS1Switch" class="float-right mt-n1 mb-n2" style="display:<?php if (strpos(json_encode($RproxySconf), 'mapping') !== false) echo 'none'; else echo 'block';?>">
<button type="button" class="btn btn-secondary btn-sm mt-1" style="border-Radius: 0px;" onclick="RproxyS1Switch()">展开</button>
</span>
              </div>
              <div id="RproxyS1Body" class="card-body" style="display:<?php if (strpos(json_encode($RproxySconf), 'mapping') !== false) echo 'block'; else echo 'none';?>">
                <div id="RproxyS1List" class="form-row">
<?php 
$rproxyS1Mappings = (isset($de_GWDconf->FORWARD->Rproxy->server->mapping) && is_array($de_GWDconf->FORWARD->Rproxy->server->mapping)) ? array_values($de_GWDconf->FORWARD->Rproxy->server->mapping) : [];
for( $i=0; $i<count($rproxyS1Mappings); $i++){
  $mapObj = is_object($rproxyS1Mappings[$i]) ? $rproxyS1Mappings[$i] : new stdClass();
  $RproxyS1Port = gwd_h($mapObj->port ?? '');
  $RproxyS1Protocol = gwd_h($mapObj->protocol ?? '');
print <<<EOT
<div class="col-md-4 input-group my-2">
  <div class="input-group-prepend">
    <span class="input-group-text">外部端口</span>
  </div>
    <input id="RproxyS1Port$i" type="text" class="form-control" value="$RproxyS1Port">
  <div class="input-group-prepend input-group-append">
    <button id="RproxyS1Protocol$i" type="button" data-toggle="dropdown" class="btn btn-outline-secondary dropdown-toggle">$RproxyS1Protocol</button>
      <div class="dropdown-menu">
        <a class="dropdown-item" onclick="RproxyS1TCP(this)" href="javascript:void(0)">tcp</a>
        <a class="dropdown-item" onclick="RproxyS1UDP(this)" href="javascript:void(0)">udp</a>
        <a class="dropdown-item" onclick="RproxyS1TCPUDP(this)" href="javascript:void(0)">tcp,udp</a>
      </div>
  </div>
  <div class="input-group-append">
    <button type="button" class="btn btn-secondary btn-sm" onclick="mappingServerDel(this)">删除</button>
  </div>
</div>
EOT;
}
?>
                </div>
              </div>
            </div>
          </div>
        </div>

    <div class="card bg-light border-secondary mb-3">
          <div class="card-header">
            <i class="far fa-share-square"></i>
            内网穿透 客户端 (内网设置)
<span id="RproxyCbutton" class="float-right mt-n1 mb-n2" style="display:<?php if (empty($RproxyCconf) === false) echo 'block'; else echo 'none';?>">
<div class="btn-group">
<button id="buttonRproxyCstop" type="button" class="btn btn-outline-secondary btn-sm mt-1" style="border-Radius: 0px;">
  <span id="buttonRproxyCstopLoading"></span>
  <span>关闭</span>
</button>
<button id="buttonRproxyCsave" type="button" class="btn <?php if (empty($RproxyCconf) === false && $checkRproxyC === 'active') echo 'btn-success'; else echo 'btn-outline-secondary';?> btn-sm mt-1" style="border-Radius: 0px;">
  <span id="buttonRproxyCsaveLoading"></span>
  <span>应用</span>
</button>
</div>
</span>
<span id="RproxyCswitch" class="float-right mt-n1 mb-n2" style="display:<?php if (empty($RproxyCconf) === false) echo 'none'; else echo 'block';?>">
<button type="button" class="btn btn-secondary btn-sm mt-1" style="border-Radius: 0px;" onclick="RproxyCswitch()">展开</button>
</span>
          </div>
          <div id="RproxyCbody" class="card-body" style="display:<?php if (empty($RproxyCconf) === false) echo 'block'; else echo 'none';?>">
            <div class="form-row">
              <div class="col-md-5 input-group my-2">
                <div class="input-group-prepend">
                  <span class="input-group-text">对接地址</span>
                </div>
                  <input id="RproxyCtunnelAddress" type="text" class="form-control" value="<?php echo gwd_h($rproxyCtunnelAddr); ?>">
              </div>

              <div class="col-md-7 input-group my-2">
                <div class="input-group-prepend">
                  <span class="input-group-text">UUID</span>
                </div>
                  <input id="RproxyCtunnelUUID" type="text" class="form-control" value="<?php echo gwd_h($rproxyCtunnelUUID); ?>">
                </div>
            </div>

            <div class="card mb-3 mt-2">
              <div class="card-header">
                端口映射型
<span id="RproxyC1Button" class="float-right mt-n1 mb-n2" style="display:<?php if (strpos(json_encode($RproxyCconf), 'mapping') !== false) echo 'block'; else echo 'none';?>">
<button id="buttonRproxyC1Add" type="button" class="btn btn-secondary btn-sm mt-1" style="border-Radius: 0px;">添加</button>
<button id="buttonRproxyC1Stop" type="button" class="btn btn-outline-secondary btn-sm mt-1" style="border-Radius: 0px;">关闭</button>
</span>
<span id="RproxyC1Switch" class="float-right mt-n1 mb-n2" style="display:<?php if (strpos(json_encode($RproxyCconf), 'mapping') !== false) echo 'none'; else echo 'block';?>">
<button type="button" class="btn btn-secondary btn-sm mt-1" style="border-Radius: 0px;" onclick="RproxyC1Switch()">展开</button>
</span>
              </div>
              <div id="RproxyC1Body" class="card-body" style="display:<?php if (strpos(json_encode($RproxyCconf), 'mapping') !== false) echo 'block'; else echo 'none';?>">
                <div id="RproxyC1List" class="form-row">
<?php 
$rproxyC1Mappings = (isset($de_GWDconf->FORWARD->Rproxy->client->mapping) && is_array($de_GWDconf->FORWARD->Rproxy->client->mapping)) ? array_values($de_GWDconf->FORWARD->Rproxy->client->mapping) : [];
for( $i=0; $i<count($rproxyC1Mappings); $i++){
  $mapObj = is_object($rproxyC1Mappings[$i]) ? $rproxyC1Mappings[$i] : new stdClass();
  $RproxyC1extPort = gwd_h($mapObj->extPort ?? '');
  $RproxyC1extProtocol = gwd_h($mapObj->extProtocol ?? '');
  $RproxyC1intIP = gwd_h($mapObj->intIP ?? '');
  $RproxyC1intPort = gwd_h($mapObj->intPort ?? '');
print <<<EOT
<div class="col-md-6 input-group my-2">
  <div class="input-group-prepend">
    <span class="input-group-text">外部端口</span>
  </div>
    <input id="RproxyC1extPort$i" type="text" class="form-control" value="$RproxyC1extPort">
  <div class="input-group-prepend input-group-append">
    <button id="RproxyC1extProtocol$i" type="button" data-toggle="dropdown" class="btn btn-outline-secondary dropdown-toggle">$RproxyC1extProtocol</button>
      <div class="dropdown-menu">
        <a class="dropdown-item" onclick="RproxyC1TCP(this)" href="javascript:void(0)">tcp</a>
        <a class="dropdown-item" onclick="RproxyC1UDP(this)" href="javascript:void(0)">udp</a>
        <a class="dropdown-item" onclick="RproxyC1TCPUDP(this)" href="javascript:void(0)">tcp,udp</a>
      </div>
  </div>
  <div class="input-group-prepend">
    <span class="input-group-text">内部IP</span>
  </div>
    <input id="RproxyC1intIP$i" type="text" class="form-control" value="$RproxyC1intIP">
  <div class="input-group-prepend input-group-append">
    <span class="input-group-text">内部端口</span>
  </div>
    <input id="RproxyC1intPort$i" type="text" class="form-control" value="$RproxyC1intPort">
  <div class="input-group-append">
    <button type="button" class="btn btn-secondary btn-sm" onclick="mappingClientDel(this)">删除</button>
  </div>
</div>
EOT;
}
?>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- Page Content -->
      </div>
      

      <!-- /.container-fluid -->

      <!-- Sticky Footer -->
      <footer class="sticky-footer">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright © de_GWD by JacyL4 2017 ~ 2025</span>
          </div>
        </div>
      </footer>

    </div>
    <!-- /.content-wrapper -->

  </div>
  <!-- /#wrapper -->
<script>
function CERswitch(){
$('#CERswitch').css('display', 'none');
$('#CERbutton').css('display', 'block');
$('#CERbody').css('display', 'block');
}

function DoGsSwitch(){
$('#DoGsSwitch').css('display', 'none');
$('#DoGsButton').css('display', 'block');
$('#DoGsBody').css('display', 'block');
}

function FWD0switch(){
$('#FWD0switch').css('display', 'none');
$('#FWD0button').css('display', 'block');
$('#FWD0body').css('display', 'block');
}

function copyNodeLink(elemId, btn) {
  var copyText = document.getElementById(elemId);
  if (!copyText) return;
  copyText.select();
  copyText.setSelectionRange(0, 99999);
  var done = function() {
    var $btn = $(btn);
    var oldText = $btn.text();
    $btn.text('已复制!').removeClass('btn-outline-primary').addClass('btn-success');
    setTimeout(function() {
      $btn.text(oldText).removeClass('btn-success').addClass('btn-outline-primary');
    }, 1500);
  };
  if (navigator.clipboard && window.isSecureContext) {
    navigator.clipboard.writeText(copyText.value).then(done).catch(function() {
      document.execCommand('copy');
      done();
    });
  } else {
    document.execCommand('copy');
    done();
  }
}

// Index of a saved UUID row (1-based), counting only real rows with a non-empty UUID,
// matching the order act/FWD*save.php persists. Returns 0 for an empty/unsaved row.
function fwdSavedIndex(rowClass, uuidPrefix, $group){
var idx = 0, found = 0
$('.' + rowClass).each(function(){
  if ($.trim($(this).find("input[id^='" + uuidPrefix + "']").val() || '') !== '') {
    idx++
    if (this === $group[0]) { found = idx; return false }
  }
})
return found
}

function FWD0qr(FWD0qr){
var $group = $(FWD0qr).closest('.fwd0-row')
var FWD0index = fwdSavedIndex('fwd0-row', 'FWD0uuid', $group)
if (!FWD0index) { alert('请先填写UUID并点击“应用”保存后再生成二维码'); return }
$.get('./act/FWD0qr.php', {FWD0index:FWD0index}, function(data){
  if ($('#FWD0qrpop' + FWD0index).length === 0) {
    var markVal = $group.find("input[id^='FWD0mark']").val() || '';
    $('body').append(`
      <div id="FWD0qrpop${FWD0index}" class="modal fade" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title mx-auto"></h5>
            </div>
            <div class="modal-body">
              <div id="FWD0qrcode${FWD0index}" class="text-center mb-3"></div>
              <div class="input-group">
                <input type="text" id="FWD0link${FWD0index}" class="form-control" readonly>
                <div class="input-group-append">
                  <button class="btn btn-outline-primary" type="button" onclick="copyNodeLink('FWD0link${FWD0index}', this)">复制</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `);
    $('#FWD0qrpop' + FWD0index + ' .modal-title').text('默认中转线二维码 - ' + markVal);
  }
  $('#FWD0qrcode'+FWD0index).empty()
  $('#FWD0link'+FWD0index).val(data)
  $('#FWD0qrpop'+FWD0index).modal('show')
  $('#FWD0qrcode'+FWD0index).qrcode({width: 240,height: 240,correctLevel:0,text:data})
}).fail(function(){
  alert('请先点击“应用”保存该UUID后再生成二维码')
})
}

function FWD1switch(){
$('#FWD1switch').css('display', 'none');
$('#FWD1button').css('display', 'block');
$('#FWD1body').css('display', 'block');
}

function FWD1qr(FWD1qr){
var $group = $(FWD1qr).closest('.fwd1-row')
var FWD1index = fwdSavedIndex('fwd1-row', 'FWD1uuid', $group)
if (!FWD1index) { alert('请先填写UUID并点击“应用”保存后再生成二维码'); return }
$.get('./act/FWD1qr.php', {FWD1index:FWD1index}, function(data){
  if ($('#FWD1qrpop' + FWD1index).length === 0) {
    var markVal = $group.find("input[id^='FWD1mark']").val() || '';
    $('body').append(`
      <div id="FWD1qrpop${FWD1index}" class="modal fade" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title mx-auto"></h5>
            </div>
            <div class="modal-body">
              <div id="FWD1qrcode${FWD1index}" class="text-center mb-3"></div>
              <div class="input-group">
                <input type="text" id="FWD1link${FWD1index}" class="form-control" readonly>
                <div class="input-group-append">
                  <button class="btn btn-outline-primary" type="button" onclick="copyNodeLink('FWD1link${FWD1index}', this)">复制</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `);
    $('#FWD1qrpop' + FWD1index + ' .modal-title').text('并行中转线二维码 - ' + markVal);
  }
  $('#FWD1qrcode'+FWD1index).empty()
  $('#FWD1link'+FWD1index).val(data)
  $('#FWD1qrpop'+FWD1index).modal('show')
  $('#FWD1qrcode'+FWD1index).qrcode({width: 240,height: 240,correctLevel:0,text:data})
}).fail(function(){
  alert('请先点击“应用”保存该UUID后再生成二维码')
})
}

function buttonFWD1upstream(btn){
var $btn = $(btn)
$('#FWD1upstream').text($btn.text())
$('#FWD1upstream').val($btn.val())
}

function RproxySswitch(){
$('#RproxySswitch').css('display', 'none');
$('#RproxySbutton').css('display', 'block');
$('#RproxySbody').css('display', 'block');
}

function RproxyS1Switch(){
$('#RproxyS1Switch').css('display', 'none');
$('#RproxyS1Button').css('display', 'block');
$('#RproxyS1Body').css('display', 'block');
}

function RproxyC1Switch(){
$('#RproxyC1Switch').css('display', 'none');
$('#RproxyC1Button').css('display', 'block');
$('#RproxyC1Body').css('display', 'block');
}

function RproxyS1TCP(RproxyS1TCP){
$(RproxyS1TCP).parent().parent().find('.dropdown-toggle').html("tcp")
}

function RproxyS1UDP(RproxyS1UDP){
$(RproxyS1UDP).parent().parent().find('.dropdown-toggle').html("udp")
}

function RproxyS1TCPUDP(RproxyS1TCPUDP){
$(RproxyS1TCPUDP).parent().parent().find('.dropdown-toggle').html("tcp,udp")
}

function RproxyC1TCP(RproxyC1TCP){
$(RproxyC1TCP).parent().parent().find('.dropdown-toggle').html("tcp")
}

function RproxyC1UDP(RproxyC1UDP){
$(RproxyC1UDP).parent().parent().find('.dropdown-toggle').html("udp")
}

function RproxyC1TCPUDP(RproxyC1TCPUDP){
$(RproxyC1TCPUDP).parent().parent().find('.dropdown-toggle').html("tcp,udp")
}

function mappingServerDel(mappingServerDel){
$(mappingServerDel).parent().parent('.input-group').remove()
}

function mappingClientDel(mappingClientDel){
$(mappingClientDel).parent().parent('.input-group').remove()
}

function RproxyCswitch(){
$('#RproxyCswitch').css('display', 'none');
$('#RproxyCbutton').css('display', 'block');
$('#RproxyCbody').css('display', 'block');
};

$(function(){
$('#buttonLogout').click(function(){
$.post('auth.php', {logout:'true'}).always(function(){window.location.href="login.php"})
})

$('#buttonMarkThis').click(function(){
markNametxt=$('#markName').val()
$.post('./act/markThis.php', {markName:markNametxt}, function(result){window.location.reload()})
})

$('#buttonGenCER').click(function(){
cfdomain=$('#CFdomain').val().trim()
cftoken=$('#CFtoken').val().trim()
$.post('./act/genCER.php', {CFdomain:cfdomain, CFtoken:cftoken}, function(){
  var win = window.open('/ttyd', 'popupWindow', 'width=900, height=900, scrollbars=yes')
  if (!win) {
    alert('弹出窗口被拦截，请允许弹窗后重试');
    return;
  }
  var timer = setInterval(function() { 
    if(!win || win.closed) {
        clearInterval(timer);
        $.post('./act/installZ.php', function(result){window.location.reload()})
    }
  }, 300);
}).fail(function(xhr){
  alert($.trim(xhr.responseText) || '证书参数无效')
})
})

$('#buttonCheckCER').click(function(){
$("#buttonCheckCERloading").attr("class", "spinner-border spinner-border-sm")
$.get('./act/checkCER.php', function(data){
  $("#buttonCheckCERloading").removeClass()
  $("#buttonCheckCERtxt").text(data)
}).fail(function(){
  $("#buttonCheckCERloading").removeClass()
})
})

$('#buttonDoGsSave').click(function(){
$("#buttonDoGsSaveLoading").attr("class", "spinner-border spinner-border-sm")
DoGsPort=$('#DoGsPort').val().trim()
$.post('./act/DoGsSave.php', {DoGsPort:DoGsPort}, function(result){
  $("#buttonDoGsSaveLoading").removeClass()
  window.location.reload()
}).fail(function(xhr){
  $("#buttonDoGsSaveLoading").removeClass()
  alert($.trim(xhr.responseText) || 'DoGs保存失败')
})
})

$('#buttonDoGsStop').click(function(){
$("#buttonDoGsStopLoading").attr("class", "spinner-border spinner-border-sm")
$.post('./act/DoGsStop.php', function(result){
  $("#buttonDoGsStopLoading").removeClass()
  $("#buttonDoGsSave").attr('class','btn btn-outline-secondary btn-sm mt-1')
  $('#DoGsSwitch').css('display', 'block');
  $('#DoGsButton').css('display', 'none');
  $('#DoGsBody').css('display', 'none');
})
})

$('#buttonBlock53on').click(function(){
$("#buttonBlock53onLoading").attr("class", "spinner-border spinner-border-sm")
$.post('./act/block53on.php', function(result){
  $("#buttonBlock53onLoading").removeClass()
  $("#buttonBlock53on").attr('class','btn btn-success btn-sm mt-1')
})
})

$('#buttonBlock53off').click(function(){
$("#buttonBlock53offLoading").attr("class", "spinner-border spinner-border-sm")
$.post('./act/block53off.php', function(result){
  $("#buttonBlock53offLoading").removeClass()
  $("#buttonBlock53on").attr('class','btn btn-outline-secondary btn-sm mt-1')
})
})

$('#buttonFWD0Add').click(function(){
  var i = $(".fwd0-row").length+1
  $('#FWD0List').append(`
                <div class="input-group my-2 fwd0-row">
                  <div class="input-group-prepend">
                    <span class="input-group-text">UUID</span>
                  </div>
                    <input id="FWD0uuid${i}" type="text" class="form-control" value="">
                  <div class="input-group-prepend input-group-append">
                    <button type="button" class="btn btn-secondary" onclick="FWD0qr(this)">显示二维码</button>
                  </div>
                  <div class="input-group-prepend input-group-append">
                    <span class="input-group-text">备注</span>
                  </div>
                    <input id="FWD0mark${i}" type="text" class="form-control col-md-3" value="">
                </div>
                          `)
})

$('#buttonFWD0save').click(function(){
$("#buttonFWD0saveLoading").attr("class", "spinner-border spinner-border-sm")
FWD0port=$('#FWD0port').val().trim()
var FWD0uuidList = []
$(".fwd0-row").each(function(){
    var FWD0uuid = ($(this).find("input[id^='FWD0uuid']").val() || '').trim()
    var FWD0mark = $(this).find("input[id^='FWD0mark']").val() || ''
    if ( FWD0uuid !== '' ) {
    FWD0uuidList.push({FWD0uuid, FWD0mark})
    }
})
$.post('./act/FWD0save.php', {FWD0port:FWD0port, FWD0uuidList:FWD0uuidList}, function(result){
  $("#buttonFWD0saveLoading").removeClass()
window.location.reload()
}).fail(function(xhr){
  $("#buttonFWD0saveLoading").removeClass()
  alert($.trim(xhr.responseText) || '默认中转线保存失败')
})
})

$('#buttonFWD0stop').click(function(){
$("#buttonFWD0stopLoading").attr("class", "spinner-border spinner-border-sm")
$.post('./act/FWD0stop.php', function(result){
  $("#buttonFWD0stopLoading").removeClass()
  $("#buttonFWD0save").attr('class','btn btn-outline-secondary btn-sm mt-1')
  $('#FWD0switch').css('display', 'block');
  $('#FWD0button').css('display', 'none');
  $('#FWD0body').css('display', 'none');
})
})

$('#buttonFWD1Add').click(function(){
  var i = $(".fwd1-row").length+1
  $('#FWD1List').append(`
                <div class="input-group my-2 fwd1-row">
                  <div class="input-group-prepend">
                    <span class="input-group-text">UUID</span>
                  </div>
                    <input id="FWD1uuid${i}" type="text" class="form-control" value="">
                  <div class="input-group-prepend input-group-append">
                    <button type="button" class="btn btn-secondary" onclick="FWD1qr(this)">显示二维码</button>
                  </div>
                  <div class="input-group-prepend input-group-append">
                    <span class="input-group-text">备注</span>
                  </div>
                    <input id="FWD1mark${i}" type="text" class="form-control col-md-3" value="">
                </div>
                          `)
})

$('#buttonFWD1save').click(function(){
$("#buttonFWD1saveLoading").attr("class", "spinner-border spinner-border-sm")
FWD1upstream=$('#FWD1upstream').val()
FWD1port=$('#FWD1port').val().trim()
var FWD1uuidList = []
$(".fwd1-row").each(function(){
    var FWD1uuid = ($(this).find("input[id^='FWD1uuid']").val() || '').trim()
    var FWD1mark = $(this).find("input[id^='FWD1mark']").val() || ''
    if ( FWD1uuid !== '' ) {
    FWD1uuidList.push({FWD1uuid, FWD1mark})
    }
})
$.post('./act/FWD1save.php', {FWD1upstream:FWD1upstream, FWD1port:FWD1port, FWD1uuidList:FWD1uuidList}, function(result){
  $("#buttonFWD1saveLoading").removeClass()
window.location.reload()
}).fail(function(xhr){
  $("#buttonFWD1saveLoading").removeClass()
  alert($.trim(xhr.responseText) || '并行中转线保存失败')
})
})

$('#buttonFWD1stop').click(function(){
$("#buttonFWD1stopLoading").attr("class", "spinner-border spinner-border-sm")
$.post('./act/FWD1stop.php', function(result){
  $("#buttonFWD1stopLoading").removeClass()
  $("#buttonFWD1save").attr('class','btn btn-outline-secondary btn-sm mt-1')
  $('#FWD1switch').css('display', 'block');
  $('#FWD1button').css('display', 'none');
  $('#FWD1body').css('display', 'none');
}).fail(function(){
  $("#buttonFWD1stopLoading").removeClass()
})
})

$('#buttonRproxySsave').click(function(){
$("#buttonRproxySsaveLoading").attr("class", "spinner-border spinner-border-sm")
RproxyStunnelPort=$('#RproxyStunnelPort').val().trim()
RproxyStunnelUUID=$('#RproxyStunnelUUID').val().trim()
RproxySmappingStatus=$('#RproxyS1Body').css('display')
var RproxyS1List = []
$("#RproxyS1List .input-group").each(function(){
    var port = ($(this).find("input[id^='RproxyS1Port']").val() || '').trim()
    var protocol = $.trim($(this).find("button[id^='RproxyS1Protocol']").text())
    if ( port !== '' && protocol !== '') {
    RproxyS1List.push({port, protocol})
    }
})
$.post('./act/RproxySsave.php', {RproxyStunnelPort:RproxyStunnelPort, RproxyStunnelUUID:RproxyStunnelUUID, RproxySmappingStatus:RproxySmappingStatus, RproxyS1List:RproxyS1List}, function(result){
  $("#buttonRproxySsaveLoading").removeClass()
  window.location.reload()
}).fail(function(xhr){
  $("#buttonRproxySsaveLoading").removeClass()
  alert($.trim(xhr.responseText) || '内网穿透服务端保存失败')
})
})

$('#buttonRproxySstop').click(function(){
$("#buttonRproxySstopLoading").attr("class", "spinner-border spinner-border-sm")
$.post('./act/RproxySstop.php', function(result){
  $("#buttonRproxySstopLoading").removeClass()
  $("#buttonRproxySsave").attr('class','btn btn-outline-secondary btn-sm mt-1')
  $('#RproxySswitch').css('display', 'block'); 
  $('#RproxySbutton').css('display', 'none'); 
  $('#RproxySbody').css('display', 'none'); 
})
})

$('#buttonRproxyS1Stop').click(function(){
$('#RproxyS1Switch').css('display', 'block'); 
$('#RproxyS1Button').css('display', 'none'); 
$('#RproxyS1Body').css('display', 'none'); 
})

$('#buttonRproxyS1Add').click(function(){
  var i = $("#RproxyS1List .input-group").length
  $('#RproxyS1List').append(`
<div class="col-md-4 input-group my-2">
  <div class="input-group-prepend">
    <span class="input-group-text">外部端口</span>
  </div>
    <input id="RproxyS1Port${i}" type="text" class="form-control" value="">
  <div class="input-group-prepend input-group-append">
    <button id="RproxyS1Protocol${i}" type="button" data-toggle="dropdown" class="btn btn-outline-secondary dropdown-toggle">tcp</button>
      <div class="dropdown-menu">
        <a class="dropdown-item" onclick="RproxyS1TCP(this)" href="javascript:void(0)">tcp</a>
        <a class="dropdown-item" onclick="RproxyS1UDP(this)" href="javascript:void(0)">udp</a>
        <a class="dropdown-item" onclick="RproxyS1TCPUDP(this)" href="javascript:void(0)">tcp,udp</a>
      </div>
  </div>
  <div class="input-group-append">
    <button type="button" class="btn btn-secondary btn-sm" onclick="mappingServerDel(this)">删除</button>
  </div>
</div>
                          `)
})

$('#buttonRproxyC1Add').click(function(){
  var i = $("#RproxyC1List .input-group").length
  $('#RproxyC1List').append(`
<div class="col-md-6 input-group my-2">
  <div class="input-group-prepend">
    <span class="input-group-text">外部端口</span>
  </div>
    <input id="RproxyC1extPort${i}" type="text" class="form-control" value="">
  <div class="input-group-prepend input-group-append">
    <button id="RproxyC1extProtocol${i}" type="button" data-toggle="dropdown" class="btn btn-outline-secondary dropdown-toggle">tcp</button>
      <div class="dropdown-menu">
        <a class="dropdown-item" onclick="RproxyC1TCP(this)" href="javascript:void(0)">tcp</a>
        <a class="dropdown-item" onclick="RproxyC1UDP(this)" href="javascript:void(0)">udp</a>
        <a class="dropdown-item" onclick="RproxyC1TCPUDP(this)" href="javascript:void(0)">tcp,udp</a>
      </div>
  </div>
  <div class="input-group-prepend">
    <span class="input-group-text">内部IP</span>
  </div>
    <input id="RproxyC1intIP${i}" type="text" class="form-control" value="">
  <div class="input-group-prepend input-group-append">
    <span class="input-group-text">内部端口</span>
  </div>
    <input id="RproxyC1intPort${i}" type="text" class="form-control" value="">
  <div class="input-group-append">
    <button type="button" class="btn btn-secondary btn-sm" onclick="mappingClientDel(this)">删除</button>
  </div>
</div>
                          `)
})

$('#buttonRproxyCsave').click(function(){
$("#buttonRproxyCsaveLoading").attr("class", "spinner-border spinner-border-sm")
RproxyCtunnelAddress=$('#RproxyCtunnelAddress').val()
RproxyCtunnelUUID=$('#RproxyCtunnelUUID').val().trim()
RproxyCmappingStatus=$('#RproxyC1Body').css('display')
var RproxyC1List = []
$("#RproxyC1List .input-group").each(function(){
    var extPort = ($(this).find("input[id^='RproxyC1extPort']").val() || '').trim()
    var extProtocol = $.trim($(this).find("button[id^='RproxyC1extProtocol']").text())
    var intIP = ($(this).find("input[id^='RproxyC1intIP']").val() || '').trim()
    var intPort = ($(this).find("input[id^='RproxyC1intPort']").val() || '').trim()
    if ( extPort !== '' && extProtocol !== '' && intIP !== '' && intPort !== '') {
    RproxyC1List.push({extPort, extProtocol, intIP, intPort})
    }
})
$.post('./act/RproxyCsave.php', {RproxyCtunnelAddress:RproxyCtunnelAddress, RproxyCtunnelUUID:RproxyCtunnelUUID, RproxyCmappingStatus:RproxyCmappingStatus, RproxyC1List:RproxyC1List}, function(result){
  $("#buttonRproxyCsaveLoading").removeClass()
  window.location.reload()
}).fail(function(xhr){
  $("#buttonRproxyCsaveLoading").removeClass()
  alert($.trim(xhr.responseText) || '内网穿透客户端保存失败')
})
})

$('#buttonRproxyCstop').click(function(){
$("#buttonRproxyCstopLoading").attr("class", "spinner-border spinner-border-sm")
$.post('./act/RproxyCstop.php', function(result){
  $("#buttonRproxyCstopLoading").removeClass()
  $("#buttonRproxyCsave").attr('class','btn btn-outline-secondary btn-sm mt-1')
  $('#RproxyCswitch').css('display', 'block'); 
  $('#RproxyCbutton').css('display', 'none'); 
  $('#RproxyCbody').css('display', 'none'); 
}).fail(function(){
  $("#buttonRproxyCstopLoading").removeClass()
})
})

$('#buttonRproxyC1Stop').click(function(){
$('#RproxyC1Switch').css('display', 'block'); 
$('#RproxyC1Button').css('display', 'none'); 
$('#RproxyC1Body').css('display', 'none'); 
})

})
</script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin.min.js"></script>
  
</body>

</html>
